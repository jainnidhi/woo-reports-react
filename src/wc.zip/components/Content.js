import React from 'react';
import WooCommerceAPI from 'woocommerce-api';

const WooCommerce = new WooCommerceAPI({
	url: 'http://powerpacktest.local',
	consumerKey: 'ck_a264d9b0399050253ede1bc6b8ff0b5d90d3f162',
	consumerSecret: 'cs_e67f12ed8b926cc2df26e378faadccc021bc74de',
	wpAPI: true,
	version: 'wc/v2'
});

class Content extends React.Component {
	constructor(props) {
		super(props);

		this.state = {
			data: {},
			products: {},
			selectedProduct: ''
		};
	}

	handleSelectProduct(e) {
		this.setState({
			selectedProduct: e.target.value
		});
	}

	componentDidMount() {
		const { filter } = this.props;

		if ( 'sales-by-product' === filter ) {
			// WooCommerce.get('products?per_page=100', (err, data, res) => {
			// 	console.table(JSON.parse(res));
			// });
			WooCommerce.getAsync('products?per_page=100').then(result => {
				this.setState({ products: JSON.parse(result.toJSON().body) });
			});
		}
	}

	getEndpoint() {
		const { filter } = this.props;
		let endpoint = '';

		switch ( filter ) {
			case 'sales-by-date':
				endpoint = 'reports/sales';
				break;
			case 'sales-by-product':
				endpoint = `products/${this.state.selectedProduct}/orders`;
				break;
			default:
				break;
		}

		return endpoint;
	}

	getReports() {
		WooCommerce.get(this.getEndpoint(), (err, data, res) => {
			console.table(JSON.parse(res));
		});
	}

	render() {
		return (
			
			<div className="content">
				<div className="reports">
					<select value={this.state.selectedProduct} onChange={this.handleSelectProduct.bind(this)}>
						{this.state.products.length > 0 && this.state.products.map((product, i) =>
							<option value={product.id} key={i}>{product.name}</option>
						)}
					</select>
					<div className="reportData">
						{this.state.selectedProduct !== '' && this.getReports()}
					</div>
				</div>
			</div>
		);
	}
}


export default Content;