import React from 'react';
import Header from './Header';
import Content from './Content';

class WCReports extends React.Component {
	constructor(props) {
		super(props);
	}

	render() {
		return(
			<div className="wc-reports-filter">
				<Header header={this.props.header}/>
				<Content filter={this.props.filter}/>
			</div>
		);
	}
}


export default WCReports;