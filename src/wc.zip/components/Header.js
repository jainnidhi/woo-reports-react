import React from 'react';
import OrdersHeader from './header/OrdersHeader';
import CustomerHeader from './header/CustomerHeader';
import StockHeader from './header/StockHeader';

class Header extends React.Component {
	constructor(props) {
		super(props);
	}

	render() {
		const {header} = this.props;
		return (
			<div className="header">
				<div className="main-header">
					<ul>
						<li><a href="/woocommerce/orders">Orders</a></li>
						<li><a href="#">Customers</a></li>
						<li><a href="#">Stock</a></li>
					</ul>
				</div>
				<div className="sub-header">
					{header === 'OrdersHeader' && <OrdersHeader />}
					{header === 'CustomerHeader' && <CustomerHeader />}
					{header === 'StockHeader' && <StockHeader />}
				</div>
			</div>
		);
	}
}


export default Header;